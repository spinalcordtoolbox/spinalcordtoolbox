.. _general_examples:

Examples
========
