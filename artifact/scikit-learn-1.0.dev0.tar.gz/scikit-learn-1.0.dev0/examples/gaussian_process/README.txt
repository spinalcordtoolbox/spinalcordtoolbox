.. _gaussian_process_examples:

Gaussian Process for Machine Learning
-------------------------------------

Examples concerning the :mod:`sklearn.gaussian_process` module.

