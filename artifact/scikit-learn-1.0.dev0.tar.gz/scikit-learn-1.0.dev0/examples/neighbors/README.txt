.. _neighbors_examples:

Nearest Neighbors
-----------------------

Examples concerning the :mod:`sklearn.neighbors` module.
